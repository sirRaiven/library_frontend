<script setup lang="ts">
import type { InventoryExportRow } from "~/composables/useLibraryInventoryExcel";
import { useLibraryInventoryExcel } from "~/composables/useLibraryInventoryExcel";
import { useBarcodePrintQueue } from "~/composables/useBarcodePrintQueue";
import { useAuth } from "~/composables/useAuth";
import LiveBarcodeScanner from "~/components/librarian/visits/LiveBarcodeScanner.vue";
import type { BarcodeScanResult } from "~/composables/useBarcodeScanResult";
definePageMeta({
  layout: "librarian",
  title: "Library Collection",
});

type CopyStatus =
  | "Available"
  | "Borrowed"
  | "Reserved"
  | "Damaged"
  | "Lost"
  | "Archived";

interface BookCopy {
  id?: number;
  documentId?: string;
  accession_number?: string | null;
  control_number: string;
  shelf_location?: string | null;
  copy_status: CopyStatus;
  condition?: string | null;
}

interface BookRecord {
  id?: number;
  documentId?: string;
  title: string;
  author: string;
  isbn?: string | null;
  category?: string | null;
  publisher?: string | null;
  edition?: string | null;
  copyright_year?: number | null;
  record_status?: "Active" | "Archived";
  createdAt?: string;
  book_copies?: BookCopy[] | {
    data?: BookCopy[];
  };
}

interface BooksResponse {
  data: BookRecord[];
  meta?: {
    pagination?: {
      page: number;
      pageSize: number;
      pageCount: number;
      total: number;
    };
  };
}

interface ExportInventoryResponse {
  data: InventoryExportRow[];
  meta?: {
    total?: number;
  };
}

interface CatalogBook extends BookRecord {
  copies: BookCopy[];
  totalCopies: number;
  availableCopies: number;
  attentionCopies: number;
}

const auth = useAuth();
const toast = useToast();
const printQueue = useBarcodePrintQueue();
const inventoryExcel = useLibraryInventoryExcel();

const search = ref("");
const selectedCategory = ref("All Categories");
const page = ref(1);
const pageSize = 12;

const isLoading = ref(true);
const isExporting = ref(false);
const isBarcodeSearching = ref(false);
const isApplyingBarcodeSearch = ref(false);
const lastScannedBarcode = ref("");
const loadError = ref("");
const books = ref<CatalogBook[]>([]);
const totalBooks = ref(0);
const pageCount = ref(1);

const categoryItems = [
  "All Categories",
  "Filipiniana",
  "Reference",
  "Computer Program",
  "Health Care",
  "Business Administration",
  "Hospitality & Tourism Management",
  "Criminal Justice Education",
];

const copiesOnPage = computed(() =>
  books.value.reduce(
    (total, book) => total + book.totalCopies,
    0,
  ),
);

const availableOnPage = computed(() =>
  books.value.reduce(
    (total, book) =>
      total + book.availableCopies,
    0,
  ),
);

const attentionOnPage = computed(() =>
  books.value.reduce(
    (total, book) =>
      total + book.attentionCopies,
    0,
  ),
);

function getHttpStatus(error: unknown): number | undefined {
  const fetchError = error as {
    status?: number;
    statusCode?: number;
    response?: {
      status?: number;
    };
  };

  return (
    fetchError.response?.status ??
    fetchError.statusCode ??
    fetchError.status
  );
}

function normalizeCopies(
  relation: BookRecord["book_copies"],
): BookCopy[] {
  if (Array.isArray(relation)) {
    return relation;
  }

  if (
    relation &&
    Array.isArray(relation.data)
  ) {
    return relation.data;
  }

  return [];
}

function normalizeBook(
  book: BookRecord,
): CatalogBook {
  const copies = normalizeCopies(
    book.book_copies,
  );

  const availableCopies = copies.filter(
    (copy) =>
      copy.copy_status === "Available",
  ).length;

  const attentionCopies = copies.filter(
    (copy) =>
      copy.copy_status === "Damaged" ||
      copy.copy_status === "Lost",
  ).length;

  return {
    ...book,
    copies,
    totalCopies: copies.length,
    availableCopies,
    attentionCopies,
  };
}

function buildQuery(
  physicalBarcode = "",
): Record<string, unknown> {
  const query: Record<string, unknown> = {
    "sort[0]": "createdAt:desc",
    "pagination[page]": page.value,
    "pagination[pageSize]": pageSize,
    "populate[book_copies][fields][0]":
      "accession_number",
    "populate[book_copies][fields][1]":
      "control_number",
    "populate[book_copies][fields][2]":
      "shelf_location",
    "populate[book_copies][fields][3]":
      "copy_status",
    "populate[book_copies][fields][4]":
      "condition",
  };

  const barcode = physicalBarcode.trim();
  const keyword = search.value.trim();

  if (barcode) {
    query[
      "filters[$or][0][book_copies][control_number][$eqi]"
    ] = barcode;
    query[
      "filters[$or][1][book_copies][accession_number][$eqi]"
    ] = barcode;
  } else if (keyword) {
    query[
      "filters[$or][0][title][$containsi]"
    ] = keyword;
    query[
      "filters[$or][1][author][$containsi]"
    ] = keyword;
    query[
      "filters[$or][2][isbn][$containsi]"
    ] = keyword;
    query[
      "filters[$or][3][book_copies][control_number][$containsi]"
    ] = keyword;
    query[
      "filters[$or][4][book_copies][accession_number][$containsi]"
    ] = keyword;
  }

  if (
    selectedCategory.value !==
    "All Categories"
  ) {
    query["filters[category][$eq]"] =
      selectedCategory.value;
  }

  return query;
}

async function loadBooks(
  physicalBarcode: string | Event = "",
) {
  const barcodeFilter =
    typeof physicalBarcode === "string"
      ? physicalBarcode
      : "";

  isLoading.value = true;
  loadError.value = "";

  try {
    const response =
      await auth.authFetch<BooksResponse>(
        "/api/books",
        {
          method: "GET",
          query: buildQuery(barcodeFilter),
        },
      );

    books.value = response.data.map(
      normalizeBook,
    );

    const pagination =
      response.meta?.pagination;

    totalBooks.value =
      pagination?.total ??
      response.data.length;

    pageCount.value =
      pagination?.pageCount ?? 1;
  } catch (error) {
    if (getHttpStatus(error) === 401) {
      auth.clearSession();

      await navigateTo({
        path: "/",
        query: {
          redirect: "/librarian/books",
        },
      });

      return;
    }

    loadError.value =
      auth.getErrorMessage(error);

    toast.add({
      title: "Unable to load books",
      description: loadError.value,
      color: "error",
      icon: "i-lucide-circle-x",
    });
  } finally {
    isLoading.value = false;
  }
}

function bookRoute(book: CatalogBook) {
  const identifier =
    book.documentId ?? book.id;

  return identifier
    ? `/librarian/books/${identifier}`
    : "/librarian/books";
}

function editBookRoute(book: CatalogBook) {
  const identifier =
    book.documentId ?? book.id;

  return identifier
    ? `/librarian/books/${identifier}/edit`
    : "/librarian/books";
}

async function openBook(
  book: CatalogBook,
): Promise<void> {
  await navigateTo(bookRoute(book));
}

async function printAllCopies(
  book: CatalogBook,
) {
  if (book.copies.length === 0) {
    toast.add({
      title: "No barcode labels",
      description:
        "This book does not have any physical copies.",
      color: "warning",
      icon: "i-lucide-printer",
    });

    return;
  }

  printQueue.setPrintQueue(
    book.copies.map((copy) => ({
      controlNumber:
        copy.control_number,
      title: book.title,
      author: book.author,
      shelfLocation:
        copy.shelf_location ?? "",
    })),
    bookRoute(book),
  );

  await navigateTo(
    "/librarian/books/print",
  );
}

async function exportInventory(): Promise<void> {
  if (isExporting.value) {
    return;
  }

  isExporting.value = true;

  try {
    const response =
      await auth.authFetch<ExportInventoryResponse>(
        "/api/books/export-inventory",
        {
          method: "GET",
        },
      );

    await inventoryExcel.downloadInventoryExport(
      response.data,
    );

    toast.add({
      title: "Inventory exported",
      description: `${response.data.length} physical ${
        response.data.length === 1 ? "copy was" : "copies were"
      } written to the Excel file.`,
      color: "success",
      icon: "i-lucide-file-check-2",
    });
  } catch (error) {
    if (getHttpStatus(error) === 401) {
      auth.clearSession();

      await navigateTo({
        path: "/",
        query: {
          redirect: "/librarian/books",
        },
      });

      return;
    }

    toast.add({
      title: "Export failed",
      description: auth.getErrorMessage(error),
      color: "error",
      icon: "i-lucide-file-x-2",
    });
  } finally {
    isExporting.value = false;
  }
}

function normalizeBarcode(value: unknown) {
  return String(value ?? "")
    .replace(/[\u0000-\u001F\u007F]/g, "")
    .trim()
    .toLowerCase();
}

function findMatchingCopy(
  book: CatalogBook,
  barcode = lastScannedBarcode.value,
): BookCopy | undefined {
  const normalizedBarcode = normalizeBarcode(barcode);

  if (!normalizedBarcode) {
    return undefined;
  }

  return book.copies.find((copy) =>
    [
      copy.control_number,
      copy.accession_number,
    ].some(
      (value) =>
        normalizeBarcode(value) === normalizedBarcode,
    ),
  );
}

async function handlePhysicalBookBarcodeDetected(
  result: BarcodeScanResult,
) {
  const barcode = result.value.trim();

  if (
    !barcode ||
    isBarcodeSearching.value ||
    isLoading.value
  ) {
    return;
  }

  if (searchTimer) {
    clearTimeout(searchTimer);
    searchTimer = undefined;
  }

  isBarcodeSearching.value = true;
  isApplyingBarcodeSearch.value = true;
  lastScannedBarcode.value = barcode;
  search.value = barcode;
  selectedCategory.value = "All Categories";
  page.value = 1;

  try {
    await nextTick();
    await loadBooks(barcode);

    const matchingBook = books.value.find((book) =>
      findMatchingCopy(book, barcode),
    );
    const matchingCopy = matchingBook
      ? findMatchingCopy(matchingBook, barcode)
      : undefined;

    if (matchingBook && matchingCopy) {
      toast.add({
        title: "Physical book found",
        description: `${matchingBook.title} • ${
          matchingCopy.control_number ||
          matchingCopy.accession_number ||
          barcode
        } • ${matchingCopy.copy_status}`,
        color: "success",
        icon: "i-lucide-book-check",
      });
    } else {
      toast.add({
        title: "Physical book not found",
        description:
          "No book copy in the collection matches the scanned barcode or accession number.",
        color: "warning",
        icon: "i-lucide-scan-search",
      });
    }
  } finally {
    isBarcodeSearching.value = false;

    await nextTick();
    isApplyingBarcodeSearch.value = false;
  }
}

function clearFilters() {
  search.value = "";
  lastScannedBarcode.value = "";
  selectedCategory.value =
    "All Categories";
  page.value = 1;
}

let searchTimer:
  | ReturnType<typeof setTimeout>
  | undefined;

watch(search, () => {
  if (isApplyingBarcodeSearch.value) {
    return;
  }

  lastScannedBarcode.value = "";

  if (searchTimer) {
    clearTimeout(searchTimer);
  }

  searchTimer = setTimeout(() => {
    page.value = 1;
    void loadBooks();
  }, 350);
});

watch(selectedCategory, () => {
  if (isApplyingBarcodeSearch.value) {
    return;
  }

  page.value = 1;
  void loadBooks();
});

watch(page, () => {
  if (isApplyingBarcodeSearch.value) {
    return;
  }

  void loadBooks();
});

onMounted(() => {
  void loadBooks();
});

onBeforeUnmount(() => {
  if (searchTimer) {
    clearTimeout(searchTimer);
  }
});
</script>

<template>
  <UContainer class="py-6 sm:py-8">
    <div class="space-y-6">
      <div
        class="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between"
      >
        <div>
          <div
            class="flex flex-wrap items-center gap-2"
          >
            <h1
              class="text-2xl font-bold tracking-tight text-highlighted sm:text-3xl"
            >
              Library Collection
            </h1>

            <UBadge
              color="neutral"
              variant="soft"
            >
              {{ totalBooks }} book
              {{
                totalBooks === 1
                  ? "title"
                  : "titles"
              }}
            </UBadge>
          </div>

          <p class="mt-1 text-sm text-muted">
            Register books manually or import existing Excel records, then
            manage physical copies, accession numbers, and barcodes from one
            place.
          </p>
        </div>

        <div class="flex flex-wrap gap-2">
          <UButton
            to="/librarian/books/import"
            label="Import Excel"
            icon="i-lucide-file-up"
            color="neutral"
            variant="outline"
          />

          <UButton
            label="Export Excel"
            icon="i-lucide-file-down"
            color="neutral"
            variant="outline"
            :loading="isExporting"
            @click="exportInventory"
          />

          <UButton
            to="/librarian/books/copies"
            label="Physical Copies"
            icon="i-lucide-book-copy"
            color="neutral"
            variant="outline"
          />

          <UButton
            to="/librarian/books/register"
            label="Register Book"
            icon="i-lucide-plus"
            color="success"
          />
        </div>
      </div>

      <UCard>
        <div
          class="grid gap-3 md:grid-cols-[minmax(0,1fr)_15rem_auto]"
        >
          <div class="space-y-2">
            <div
              class="flex flex-col gap-3 sm:flex-row sm:items-stretch"
            >
              <UInput
                v-model="search"
                icon="i-lucide-search"
                placeholder="Search title, author, ISBN, accession no., or book barcode"
                size="lg"
                :loading="isLoading"
                class="min-w-0 flex-1"
              >
                <template #trailing>
                  <UKbd>Enter</UKbd>
                </template>
              </UInput>

              <LiveBarcodeScanner
                :disabled="isLoading || isBarcodeSearching"
                title="Scan Physical Book Barcode"
                button-label="Scan Book"
                ready-description="Place the complete physical book barcode inside the guide."
                processing-label="Searching collection"
                processing-description="Please wait while the physical book is being located."
                storage-key="sncbt-book-collection-camera"
                :duplicate-cooldown-ms="5000"
                :detection-hold-ms="900"
                @detected="handlePhysicalBookBarcodeDetected"
              />
            </div>

            <p class="text-xs text-muted">
              Search by book information, scan a physical copy, or enter its control or accession number manually.
            </p>
          </div>

          <USelect
            v-model="selectedCategory"
            :items="categoryItems"
            icon="i-lucide-tags"
            size="lg"
            class="w-full"
          />

          <UButton
            label="Refresh"
            icon="i-lucide-refresh-cw"
            color="neutral"
            variant="outline"
            size="lg"
            :loading="isLoading"
            @click="loadBooks"
          />
        </div>
      </UCard>

      <div
        class="grid grid-cols-2 gap-3 lg:grid-cols-4"
      >
        <UCard>
          <div class="flex items-center gap-3">
            <div
              class="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary"
            >
              <UIcon
                name="i-lucide-library"
                class="size-5"
              />
            </div>

            <div>
              <p
                class="text-2xl font-bold text-highlighted"
              >
                {{ totalBooks }}
              </p>
              <p class="text-xs text-muted">
                Book titles
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <div class="flex items-center gap-3">
            <div
              class="flex size-10 shrink-0 items-center justify-center rounded-xl bg-info/10 text-info"
            >
              <UIcon
                name="i-lucide-book-copy"
                class="size-5"
              />
            </div>

            <div>
              <p
                class="text-2xl font-bold text-highlighted"
              >
                {{ copiesOnPage }}
              </p>
              <p class="text-xs text-muted">
                Copies shown
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <div class="flex items-center gap-3">
            <div
              class="flex size-10 shrink-0 items-center justify-center rounded-xl bg-success/10 text-success"
            >
              <UIcon
                name="i-lucide-circle-check"
                class="size-5"
              />
            </div>

            <div>
              <p
                class="text-2xl font-bold text-success"
              >
                {{ availableOnPage }}
              </p>
              <p class="text-xs text-muted">
                Available shown
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <div class="flex items-center gap-3">
            <div
              class="flex size-10 shrink-0 items-center justify-center rounded-xl bg-warning/10 text-warning"
            >
              <UIcon
                name="i-lucide-triangle-alert"
                class="size-5"
              />
            </div>

            <div>
              <p
                class="text-2xl font-bold text-warning"
              >
                {{ attentionOnPage }}
              </p>
              <p class="text-xs text-muted">
                Need attention
              </p>
            </div>
          </div>
        </UCard>
      </div>

      <UAlert
        v-if="loadError"
        color="error"
        variant="soft"
        icon="i-lucide-circle-alert"
        title="The catalog could not be loaded"
        :description="loadError"
        :actions="[
          {
            label: 'Try again',
            color: 'error',
            variant: 'outline',
            onClick: loadBooks,
          },
        ]"
      />

      <div
        v-if="isLoading"
        class="grid gap-4 xl:grid-cols-2"
      >
        <UCard
          v-for="item in 6"
          :key="item"
        >
          <div class="flex gap-4">
            <USkeleton
              class="h-32 w-24 shrink-0 rounded-xl"
            />

            <div class="flex-1 space-y-3">
              <USkeleton class="h-5 w-3/4" />
              <USkeleton class="h-4 w-1/2" />
              <USkeleton class="h-16 w-full" />
              <USkeleton class="h-9 w-40" />
            </div>
          </div>
        </UCard>
      </div>

      <div
        v-else-if="books.length > 0"
        class="grid gap-4 xl:grid-cols-2"
      >
        <UCard
          v-for="book in books"
          :key="book.documentId ?? book.id"
          class="group"
        >
          <div
            class="flex flex-col gap-5 sm:flex-row"
          >
            <button
              type="button"
              class="flex h-36 w-full shrink-0 items-center justify-center rounded-2xl border border-default bg-elevated transition-colors hover:bg-accented sm:w-28"
              :aria-label="`Open ${book.title}`"
              @click="openBook(book)"
            >
              <UIcon
                name="i-lucide-book-open"
                class="size-10 text-muted transition-transform group-hover:scale-105"
              />
            </button>

            <div class="min-w-0 flex-1">
              <div
                class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"
              >
                <button
                  type="button"
                  class="min-w-0 text-left"
                  @click="openBook(book)"
                >
                  <h2
                    class="line-clamp-2 text-lg font-semibold text-highlighted hover:text-primary"
                  >
                    {{ book.title }}
                  </h2>

                  <p
                    class="mt-1 truncate text-sm text-muted"
                  >
                    {{ book.author }}
                  </p>
                </button>

                <UBadge
                  :color="
                    book.record_status ===
                    'Archived'
                      ? 'neutral'
                      : 'success'
                  "
                  variant="soft"
                  class="self-start"
                >
                  {{
                    book.record_status ??
                    "Active"
                  }}
                </UBadge>
              </div>

              <div
                class="mt-4 grid gap-2 text-sm sm:grid-cols-2"
              >
                <div>
                  <p class="text-xs text-muted">
                    ISBN
                  </p>
                  <p
                    class="truncate font-medium text-highlighted"
                  >
                    {{ book.isbn || "Not provided" }}
                  </p>
                </div>

                <div>
                  <p class="text-xs text-muted">
                    Category
                  </p>
                  <p
                    class="truncate font-medium text-highlighted"
                  >
                    {{
                      book.category ||
                      "Uncategorized"
                    }}
                  </p>
                </div>
              </div>

              <div
                class="mt-4 flex flex-wrap gap-2"
              >
                <UBadge
                  color="neutral"
                  variant="soft"
                >
                  {{ book.totalCopies }} total
                </UBadge>

                <UBadge
                  :color="
                    book.availableCopies > 0
                      ? 'success'
                      : 'warning'
                  "
                  variant="soft"
                >
                  {{ book.availableCopies }}
                  available
                </UBadge>

                <UBadge
                  v-if="
                    book.attentionCopies > 0
                  "
                  color="error"
                  variant="soft"
                >
                  {{ book.attentionCopies }}
                  need attention
                </UBadge>
              </div>

              <div
                v-if="findMatchingCopy(book)"
                class="mt-4 flex items-start gap-3 rounded-xl border border-success/30 bg-success/5 p-3"
              >
                <div
                  class="flex size-9 shrink-0 items-center justify-center rounded-lg bg-success/10 text-success"
                >
                  <UIcon
                    name="i-lucide-scan-barcode"
                    class="size-4.5"
                  />
                </div>

                <div class="min-w-0">
                  <p class="text-xs font-semibold uppercase tracking-wide text-success">
                    Matching physical copy found
                  </p>
                  <p class="mt-1 break-all font-mono text-sm font-semibold text-highlighted">
                    {{
                      findMatchingCopy(book)?.control_number ||
                      findMatchingCopy(book)?.accession_number
                    }}
                  </p>
                  <p class="mt-1 text-xs text-muted">
                    Accession:
                    {{ findMatchingCopy(book)?.accession_number || "Not provided" }}
                    · Status:
                    {{ findMatchingCopy(book)?.copy_status }}
                    · Shelf:
                    {{ findMatchingCopy(book)?.shelf_location || "Not assigned" }}
                  </p>
                </div>
              </div>

              <div
                class="mt-5 flex flex-wrap gap-2"
              >
                <UButton
                  label="Open Record"
                  icon="i-lucide-arrow-right"
                  trailing
                  color="primary"
                  variant="soft"
                  @click="openBook(book)"
                />

                <UButton
                  :to="editBookRoute(book)"
                  label="Edit Book"
                  icon="i-lucide-pencil"
                  color="neutral"
                  variant="outline"
                />

                <UButton
                  label="Print All Labels"
                  icon="i-lucide-printer"
                  color="neutral"
                  variant="ghost"
                  :disabled="
                    book.totalCopies === 0
                  "
                  @click="printAllCopies(book)"
                />
              </div>
            </div>
          </div>
        </UCard>
      </div>

      <UCard v-else>
        <div
          class="flex flex-col items-center px-4 py-12 text-center"
        >
          <div
            class="flex size-14 items-center justify-center rounded-2xl bg-elevated text-muted"
          >
            <UIcon
              name="i-lucide-book-open"
              class="size-7"
            />
          </div>

          <h2
            class="mt-4 font-semibold text-highlighted"
          >
            {{
              lastScannedBarcode
                ? "Physical book not found"
                : "No books found"
            }}
          </h2>

          <p
            class="mt-1 max-w-md text-sm text-muted"
          >
            {{
              lastScannedBarcode
                ? `No physical copy matches ${lastScannedBarcode}. Check the barcode or register the book copy first.`
                : "Change the search filters or register a new book to begin building the library collection."
            }}
          </p>

          <div
            class="mt-5 flex flex-wrap justify-center gap-2"
          >
            <UButton
              v-if="
                search ||
                selectedCategory !==
                  'All Categories'
              "
              label="Clear Filters"
              color="neutral"
              variant="outline"
              @click="clearFilters"
            />

            <UButton
              to="/librarian/books/register"
              label="Register Book"
              icon="i-lucide-plus"
              color="success"
            />
          </div>
        </div>
      </UCard>

      <div
        v-if="pageCount > 1"
        class="flex flex-col gap-3 rounded-xl border border-default bg-default p-4 sm:flex-row sm:items-center sm:justify-between"
      >
        <p class="text-sm text-muted">
          Page {{ page }} of {{ pageCount }}
        </p>

        <UPagination
          v-model:page="page"
          :total="totalBooks"
          :items-per-page="pageSize"
          show-edges
          :sibling-count="1"
        />
      </div>
    </div>
  </UContainer>
</template>
